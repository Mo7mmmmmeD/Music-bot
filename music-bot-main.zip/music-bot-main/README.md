# Discord.js v14 Slash Commands Music Bot
- `Distube v4.0.0` , `Discord.js v14.0.1` , `ST.db v4.0.7`,

## If you want to see the Replit version
- [Click here](https://replit.com/@Shuruhatik/music-bot-by-shuruhatik?v=1#README.md)

## Contact
**Any bug or suggestion !**
 - Contact With Me Discord: [`Shuruhatik#2443`](https://github.com/shuruhatik)
### Server Support
<a  href="https://dsc.gg/shuruhatik"><img  src="https://discord.com/api/guilds/766364402763956254/widget.png?style=banner3"></a>

## If you have a problem or have a suggestion,
- Contact With Me Discord: [`Shuruhatik#2443`](https://github.com/shuruhatik)
- [Github](https://github.com/shuruhatik) | [Youtube](https://www.youtube.com/channel/UCXSrBk2f9wzB-fugmRR4wsg)

LICENSE
# [Boost Software License 1.0](./LICENSE)
